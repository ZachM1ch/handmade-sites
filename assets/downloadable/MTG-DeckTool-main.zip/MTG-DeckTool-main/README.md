# MTG-DeckTool
An project using the Scryfall REST API with Python to make the process of building and ordering Magic: The Gathering decks easier
